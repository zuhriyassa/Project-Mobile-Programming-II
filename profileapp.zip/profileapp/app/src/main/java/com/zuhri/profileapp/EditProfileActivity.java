package com.zuhri.profileapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        ImageView btnBack = findViewById(R.id.btnBack);
        EditText etName = findViewById(R.id.etName);
        EditText etUsername = findViewById(R.id.etUsername);
        EditText etBio = findViewById(R.id.etBio);
        EditText etContact = findViewById(R.id.etContact);
        Spinner spCountry = findViewById(R.id.spCountry);
        Button btnSave = findViewById(R.id.btnSave);

        String[] countries = {"Indonesia", "Malaysia", "Singapore", "United States", "Japan"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, countries);
        spCountry.setAdapter(adapter);

        // Isi form dengan data yang tersimpan
        SharedPreferences prefs = getSharedPreferences("profile", MODE_PRIVATE);
        etName.setText(prefs.getString("name", "Devon Lane"));
        etUsername.setText(prefs.getString("username", ""));
        etBio.setText(prefs.getString("bio", ""));
        etContact.setText(prefs.getString("contact", ""));
        spCountry.setSelection(prefs.getInt("country", 0));

        btnBack.setOnClickListener(v -> finish());

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String username = etUsername.getText().toString().trim();
            String bio = etBio.getText().toString().trim();
            String contact = etContact.getText().toString().trim();

            if (name.isEmpty() || username.isEmpty()) {
                Toast.makeText(this, "Name dan Username wajib diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            prefs.edit()
                    .putString("name", name)
                    .putString("username", username)
                    .putString("bio", bio)
                    .putString("contact", contact)
                    .putInt("country", spCountry.getSelectedItemPosition())
                    .apply();

            Toast.makeText(this, "Perubahan disimpan", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}