package com.zuhri.loginapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegister;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences("login_session", MODE_PRIVATE);
        if (prefs.getBoolean("logged_in", false)) {
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
            return;
        }

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> login());
        tvRegister.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, RegisterActivity.class)));
    }

    private void login() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email dan password wajib diisi.", Toast.LENGTH_SHORT).show();
            return;
        }

        btnLogin.setEnabled(false);
        JSONObject body = new JSONObject();
        try {
            body.put("email", email);
            body.put("password", password);
        } catch (Exception ignored) {}

        ApiClient.post("login.php", body, new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject result) {
                runOnUiThread(() -> {
                    btnLogin.setEnabled(true);
                    JSONObject user = result.optJSONObject("data");
                    if (user == null) {
                        Toast.makeText(MainActivity.this, "Data pengguna tidak ditemukan.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    getSharedPreferences("login_session", MODE_PRIVATE).edit()
                            .putBoolean("logged_in", true)
                            .putInt("user_id", user.optInt("id"))
                            .putString("nama", user.optString("nama"))
                            .putString("email", user.optString("email"))
                            .apply();
                    startActivity(new Intent(MainActivity.this, DashboardActivity.class));
                    finish();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    btnLogin.setEnabled(true);
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}