package com.zuhri.loginapp;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {
    // Android Emulator -> localhost komputer. Ganti dengan alamat server jika memakai HP fisik.
    private static final String BASE_URL = "http://127.0.0.1:8080/login_api/";

    public interface Callback {
        void onSuccess(JSONObject result);
        void onError(String message);
    }

    public static void post(String endpoint, JSONObject body, Callback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(BASE_URL + endpoint);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = connection.getOutputStream()) {
                    os.write(bytes);
                }

                int status = connection.getResponseCode();
                InputStream stream = (status >= 200 && status < 400)
                        ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder response = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) response.append(line);
                }
                JSONObject json = new JSONObject(response.toString());
                if (status >= 200 && status < 300 && json.optBoolean("success")) {
                    callback.onSuccess(json);
                } else {
                    callback.onError(json.optString("message", "Permintaan gagal."));
                }
            } catch (Exception e) {
                callback.onError("Tidak dapat terhubung ke server. Periksa Apache, MySQL, dan URL API.");
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }
}
