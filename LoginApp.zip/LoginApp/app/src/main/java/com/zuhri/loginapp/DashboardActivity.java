package com.zuhri.loginapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        SharedPreferences prefs = getSharedPreferences("login_session", MODE_PRIVATE);
        if (!prefs.getBoolean("logged_in", false)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        TextView tvSapaan = findViewById(R.id.tvSapaan);
        TextView tvProfil = findViewById(R.id.tvProfil);
        Button btnLogout = findViewById(R.id.btnLogout);

        String nama = prefs.getString("nama", "Pengguna");
        String email = prefs.getString("email", "-");
        tvSapaan.setText("Halo, " + nama + "!");
        tvProfil.setText(nama + "\n" + email);
        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            Intent intent = new Intent(DashboardActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}