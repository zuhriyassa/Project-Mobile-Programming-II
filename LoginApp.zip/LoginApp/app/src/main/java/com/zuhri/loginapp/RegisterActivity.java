package com.zuhri.loginapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {
    private EditText etNama, etEmail, etPassword, etKonfirmasi;
    private Button btnDaftar;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etNama = findViewById(R.id.etNama);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etKonfirmasi = findViewById(R.id.etKonfirmasi);
        btnDaftar = findViewById(R.id.btnDaftar);
        TextView tvLogin = findViewById(R.id.tvLogin);

        btnDaftar.setOnClickListener(v -> register());
        tvLogin.setOnClickListener(v -> finish());
    }

    private void register() {
        String nama = etNama.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        String konfirmasi = etKonfirmasi.getText().toString();

        if (nama.isEmpty() || email.isEmpty() || password.isEmpty() || konfirmasi.isEmpty()) {
            Toast.makeText(this, "Semua kolom wajib diisi.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Format email tidak valid.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 8) {
            Toast.makeText(this, "Password minimal 8 karakter.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!password.equals(konfirmasi)) {
            Toast.makeText(this, "Konfirmasi password tidak sama.", Toast.LENGTH_SHORT).show();
            return;
        }

        btnDaftar.setEnabled(false);
        JSONObject body = new JSONObject();
        try {
            body.put("nama", nama);
            body.put("email", email);
            body.put("password", password);
        } catch (Exception ignored) {}

        ApiClient.post("register.php", body, new ApiClient.Callback() {
            @Override public void onSuccess(JSONObject result) {
                runOnUiThread(() -> {
                    btnDaftar.setEnabled(true);
                    Toast.makeText(RegisterActivity.this, result.optString("message", "Registrasi berhasil."), Toast.LENGTH_LONG).show();
                    finish();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    btnDaftar.setEnabled(true);
                    Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}